import { useState } from "react";
import { useNavigate } from 'react-router-dom';
import axios from "axios";

function Register() {

    const [firstname, setfirstname] = useState("");
    const [lastname, setlastname] = useState("");
    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");
    const [dob, setdob] = useState("");
    const [mobileno, setmobileno] = useState("");
    const [address, setaddress] = useState("");
    const [pincode, setpincode] = useState("");
    const [state, setstate] = useState("");
    const navigate = useNavigate();
    function loginNavi(event){
        event.preventDefault();
        navigate('/login');
    }

    async function save(event) {
        event.preventDefault();
        try {
            await axios.post("http://localhost:8080/api/register", {
                firstname: firstname,
                lastname: lastname,
                email: email,
                password: password,
                dob:dob,
                mobileno:mobileno,
                address:address,
                pincode:pincode,
                state:state,
            });
            // alert("Employee Registation Successfully");
            navigate('/login');

        } catch (err) {
            alert(err);
        }
    }
    return (
       <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
          <div className="sm:mx-auto sm:w-full sm:max-w-sm">
            <img
              className="mx-auto h-10 w-auto"
              src="https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=600"
              alt="Your Company"
            />
            <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
              Sign in to your account
            </h2>
          </div>
  
          <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
            <form className="space-y-6" action="#" method="POST" onSubmit="/home">
                 <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="firstname" className="block text-sm font-medium leading-6 text-gray-900">
                    FirstName*
                  </label>
                </div>
                <div className="mt-2">
                  <input
                    id="firstname"
                    type="text"
                   value={firstname}
                                onChange={(event) => {
                                    setfirstname(event.target.value);
                                }}
                    // autoComplete="current-firstname"
                    required
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>
                        <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="lastname" className="block text-sm font-medium leading-6 text-gray-900">
                    LastName*
                  </label>
                </div>
                <div className="mt-2">
                  <input
                    id="lastname"
                    type="text"
                    value={lastname}
                                onChange={(event) => {
                                    setlastname(event.target.value);
                                }}
                    // autoComplete="current-lastname"
                    required
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>

                        <div>
                <label htmlFor="email" className="block text-sm font-medium leading-6 text-gray-900">
                  Email address*
                </label>
                <div className="mt-2">
                  <input
                    id="email"
                    type="email"
                     value={email}
                                onChange={(event) => {
                                    setemail(event.target.value);
                                }}
                    // autoComplete="email"
                    required
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>
                         <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="password" className="block text-sm font-medium leading-6 text-gray-900">
                    Password*
                  </label>
                </div>
                <div className="mt-2">
                  <input
                    id="password"
                    type="password"
                  value={password}
                                onChange={(event) => {
                                    setpassword(event.target.value);
                                }}
                    // autoComplete="current-password"
                    required
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>
                        <div>
              <div className="flex items-center justify-between">
                <label htmlFor="Dob" className="block text-sm font-medium leading-6 text-gray-900">
                  DateofBirth
                </label>
              </div>
              <div className="mt-2">
                <input
                  id="dob"
                //   autoComplete="date"
                  type="date"
                  value={dob}
                                onChange={(event) => {
                                    setdob(event.target.value);
                                }}
                  required
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                 />
              </div>
            </div>
                        <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="mobileno" className="block text-sm font-medium leading-6 text-gray-900">
                    MobileNumber
                  </label>
                </div>
                <div className="mt-2">
                  <input
                    id="mobileno"
                    type="text"
                    value={mobileno}
                                onChange={(event) => {
                                    setmobileno(event.target.value);
                                }}
                    // autoComplete="current-mobileno"
                    required
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>
                        <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="address" className="block text-sm font-medium leading-6 text-gray-900">
                    Address
                  </label>
                </div>
                <div className="mt-2">
                  <textarea
                    id="address"
                     value={address}
                                onChange={(event) => {
                                    setaddress(event.target.value);
                                }}
                    // autoComplete="address"
                    required
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                   rows="4" cols="50"/>
                </div>
              </div>
         
                        <div>
              <div className="flex items-center justify-between">
                <label htmlFor="state" className="block text-sm font-medium leading-6 text-gray-900">
                  State
                </label>
              </div>
              <div className="mt-2">
  
                   <select  id="state" autoComplete="state" className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">                   
                    <option value="Telangana">Telangana</option>
                    <option value="Andra Pradesh">Andra Pradesh</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    value={state}
                                onChange={(event) => {
                                    setstate(event.target.value);
                                }}</select>
              </div>
            </div>
                        <div>
              <div className="flex items-center justify-between">
                <label htmlFor="pincode" className="block text-sm font-medium leading-6 text-gray-900">
                  PinCode
                </label>
              </div>
              <div className="mt-2">
                <input
                  id="pincode"
                  value={pincode}
                                onChange={(event) => {
                                    setpincode(event.target.value);
                                }}
                //   autoComplete="pincode"
                  type="text"
                  required
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                 />
              </div>
            </div>
                        <div>
                <button
                  type="submit"
                  className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                onClick={save}>
                  Create account
                </button>
              </div>
            </form>
          </div>
        </div>
    );
}

export default Register;