import React, { useState } from 'react';
import './MutualFundPage.css';

const Portfolio = () => {
    const portfolioData = [
        { id: 1, STOCK: 'Century Plyboards India', SHARES_BOUGHT: '10.35 Lakh', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 2, STOCK: 'GMR Airports', SHARES_BOUGHT: '45.00 Lakh', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.01, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 3, STOCK: 'Indian oil Corp', SHARES_BOUGHT: '1.00 Lakh', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 3.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 4, STOCK: 'Westlife Development', SHARES_BOUGHT: '1.56 Lakh', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 2.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 5, STOCK: 'NMDC', SHARES_BOUGHT: '1.8 Lakh', VALUES_OF_SHARES: '5.0 Lakh', LTP: 0.068, RETURNS_SINCE_MAY: 3.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 6, STOCK: 'Indian Hotels Co', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 7, STOCK: 'General Ins Corp Of India', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 5.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 8, STOCK: 'Sudarshan Chemical', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 6.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 9, STOCK: 'ICIC Bank', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 7.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 10, STOCK: 'Exide Industries', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 8.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 11, STOCK: 'Sun Tv Network', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 9.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 12, STOCK: 'TCNS Clothing Co', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 2.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 13, STOCK: 'MOIL', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 3.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 14, STOCK: 'GE T&D India', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 15, STOCK: 'HDFC Bank', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 16, STOCK: 'Mahindra & Mahindra', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 17, STOCK: 'Rites', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 18, STOCK: 'Aditya Birla Fashion', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -1.37 },
        { id: 19, STOCK: 'Adani Ports', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -2.47 },
        { id: 20, STOCK: 'Mahanagar Gas', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -0.47 },
        { id: 21, STOCK: 'NMDC', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.02, RETURNS_BETWEEN_JAN_APR: -2.47 },
        { id: 22, STOCK: 'Tanla Platforms', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 4.05, RETURNS_BETWEEN_JAN_APR: -1.47 },
        { id: 23, STOCK: 'Timken India', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 1.02, RETURNS_BETWEEN_JAN_APR: -1.67 },
        { id: 24, STOCK: 'Bharti Airtel', SHARES_BOUGHT: 'Tax saving', VALUES_OF_SHARES: 5000, LTP: 0.068, RETURNS_SINCE_MAY: 1.02, RETURNS_BETWEEN_JAN_APR: -1.48 },

    ];

    return (
        <div>
            <center>
                <h2 style={{ color: '#2C3539' }}>List of Stocks</h2>
                <table border={"1"} cellPadding={"4"} cellSpacing={"2"} style={{ width: '80%' }}>
                    <thead>
                        <tr style={{ backgroundColor: '#78C7C7' }}>
                            <th>id</th>
                            <th>STOCK</th>
                            <th>SHARES_BOUGHT</th>
                            <th>VALUES_OF_SHARES</th>
                            <th>LTP</th>
                            <th>RETURNS_SINCE_MAY</th>
                            <th>RETURNS_BETWEEN_JAN_APR</th>
                        </tr>
                    </thead>
                    <tbody>
                        {portfolioData.map((stock) => (
                            <tr key={stock.id} style={{ backgroundColor: stock.id % 2 === 0 ? '#77BFC7' : '#78C7C7' }}>
                                <td>{stock.id}</td>
                                <td>{stock.STOCK}</td>
                                <td>{stock.SHARES_BOUGHT}</td>
                                <td>{stock.VALUES_OF_SHARES}</td>
                                <td>{stock.LTP}</td>
                                <td>{stock.RETURNS_SINCE_MAY}</td>
                                <td>{stock.RETURNS_BETWEEN_JAN_APR}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </center>
        </div>
    );
};

const StockPage = () => {
    return (
        <div style={{  padding: '10px' }}>
            <header>
               
                <h2> INFINITY WALLET STOCKS</h2>
                <p>
                    The BSE Sensex has rallied nearly 6 per cent since the government announced a corporate tax cut on September 20.
                    However, all are not lucky as four-fifths of the BSE 500 stocks have underperformed the benchmark index during this period.
                    Only about 36 stocks among BSE 500 have strongly bounced back since the finance minister’s announcement rallying over 10 per cent.
                    Some stocks in this group such as Century Plyboards, Ashok Leyland, Indian Oil Corp, Westlife Development, Indian Hotels, GIC and Su 
                    Read more at:
                    https://economictimes.indiatimes.com/markets/stocks/news/20-stocks-primed-for-higher-returns/articleshow/71532648.cms?utm_source=contentofinterest&utm_medium=text&utm_campaign=cppst
                </p>
            </header>

            <div style={{ marginRight: '20px' }}>
                <img
                    src="images/stock.png"
                    alt="Graph"
                    style={{ backgroundColor: '#CFECEC', width: '100', height: 'auto' }}
                />
            </div>
            <p>
                If you buy a stock today, the credit is given by the end of the day.

                The stock exchange also ensures that the trade of stocks is honoured during the settlement.

                If the settlement cycle doesn’t happen in T+2 days, the sanctity of the stock market is lost because it means trades may not be upheld.

                Stockbrokers identify their clients by a unique code assigned to an investor.

                After the transaction is done by an investor, the stockbroker issues him/her a contract note which provides details of the transaction, such as the time and date of the stock trade.

                Apart from the purchase price of a stock, an investor is also supposed to pay brokerage fees, stamp duty, and securities transaction tax.
            </p>
            <div style={{ marginRight: '20px' }}>
                <img
                    src="images/fore.jpg"
                    alt="Graph"
                    style={{ backgroundColor: '#CFECEC', width: '100', height: 'auto' }}
                />
            </div>
            <p>
                Once listed on the stock exchanges, the stocks issued by companies can be traded in the secondary market. This buying and selling of stocks listed on the exchanges are done by stockbrokers /brokerage firms that act as the middleman between investors and the stock exchange.

                Your broker passes on your buy order for shares to the stock exchange. The stock exchange searches for a sell order for the same share.

                Once a seller and a buyer are found, a price is agreed to finalize the transaction. Post that, the stock exchange communicates to your broker that your order has been confirmed.

                This message is then passed on to you by the broker. All this happens in real-time and in seconds.
            </p>
            <p>
            A stock market, equity market, or share market is the aggregation of buyers and sellers of stocks (also called shares), which represent ownership claims on businesses; these may include securities listed on a public stock exchange, as well as stock that is only traded privately, such as shares of private companies which are sold to investors through equity crowdfunding platforms.
             Investment is usually made with an investment strategy in mind
            </p>
            <Portfolio />
            What kinds of stocks are there?
There are two main kinds of stocks, common stock and preferred stock.

Common stock entitles owners to vote at shareholder meetings and receive dividends.

Preferred stockholders usually don’t have voting rights but they receive dividend payments before common stockholders do, and have priority over common stockholders if the company goes bankrupt and its assets are liquidated.

Common and preferred stocks may fall into one or more of the following categories:

Growth stocks have earnings growing at a faster rate than the market average. They rarely pay dividends and investors buy them in the hope of capital appreciation. A start-up technology company is likely to be a growth stock.
Income stocks pay dividends consistently. Investors buy them for the income they generate. An established utility company is likely to be an income stock.
Value stocks have a low price-to-earnings (PE) ratio, meaning they are cheaper to buy than stocks with a higher PE. Value stocks may be growth or income stocks, and their low PE ratio may reflect the fact that they have fallen out of favor with investors for some reason. People buy value stocks in the hope that the market has overreacted and that the stock’s price will rebound.
Blue-chip stocks are shares in large, well-known companies with a solid history of growth. They generally pay dividends.
Another way to categorize stocks is by the size of the company, as shown in its market capitalization. There are large-cap, mid-cap, and small-cap stocks.
        </div>
    );
};

export default StockPage;