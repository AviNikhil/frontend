import React, { useState } from 'react';
import "./MutualFundPage.css"

const MutualFundPortfolio = () => {
  const portfolioData = [
    { id: 1, fUNDNAME: 'Axis Long Term Equity', CATEGORY: 'Tax saving', SIPAMOUNT: 5000, SHARPERATIO: 0.068 },
    { id: 2, fUNDNAME: 'DSPBR Opportunities', CATEGORY: 'Debt', SIPAMOUNT: 7000, SHARPERATIO: 0.046 },
    { id: 3, fUNDNAME: 'Mirae Assest Emerging Bluechip', CATEGORY: 'Hybrid', SIPAMOUNT: 3000, SHARPERATIO: 0.048 },
    { id: 4, fUNDNAME: 'ICICI Pru Short Term Plan', CATEGORY: 'Multi Cap', SIPAMOUNT: 2000, SHARPERATIO: 0.043 },
    { id: 5, fUNDNAME: 'Principal Emerging Bluechip', CATEGORY: 'Hybrid', SIPAMOUNT: 3000, SHARPERATIO: 0.044 },
    { id: 6, fUNDNAME: 'JM Short Term', CATEGORY: 'Mid Cap', SIPAMOUNT: 8000, SHARPERATIO: 0.013 },
    { id: 7, fUNDNAME: 'Tata Dividend Yield', CATEGORY: 'Small Cap', SIPAMOUNT: 6000, SHARPERATIO: 0.043 },
    { id: 8, fUNDNAME: 'DSP Small Cap', CATEGORY: 'Large Cap', SIPAMOUNT: 3000, SHARPERATIO: 0.023 },
    { id: 9, fUNDNAME: 'Kotak BlueChip', CATEGORY: 'Hybrid', SIPAMOUNT: 3000, SHARPERATIO: 0.043 },
    { id: 10, fUNDNAME: 'Franklin India Prima', CATEGORY: 'Hybrid', SIPAMOUNT: 3000, SHARPERATIO: 0.043 },
    { id: 11, fUNDNAME: 'HDFC Capital Bulider Value', CATEGORY: 'Hybrid', SIPAMOUNT: 3000, SHARPERATIO: 0.043 },
    { id: 12, fUNDNAME: 'SBI Long Term Equity', CATEGORY: 'Small-cap', SIPAMOUNT: 3000, SHARPERATIO: 0.043 },
    { id: 13, fUNDNAME: 'Reliance Small Cap ', CATEGORY: 'Value', SIPAMOUNT: 3000, SHARPERATIO: 0.043 },
  ];

  return (
    <div className="container">
      <center>
        <h2 className="text-center" style={{ color: '#2C3539' }}>Mutual Fund Portfolio:</h2>
        <table className="table table-hover table-bordered">

          <thead className="table-primary" style={{ width: '80%', margin: 'auto' }}>
            <tr >
              <th>ID</th>
              <th>fUNDNAME</th>
              <th>CATEGORY</th>
              <th>SIPAMOUNT</th>
              <th>SHARPERATIO</th>
            </tr>
          </thead>
          <tbody>
            {portfolioData.map((fund) => (
              <tr key={fund.id} className={fund.id % 2 === 0 ? 'table-secondary' : 'table-info'}>
                <td>{fund.id}</td>
                <td>{fund.fUNDNAME}</td>
                <td>{fund.CATEGORY}</td>
                <td>{fund.SIPAMOUNT}</td>
                <td>{fund.SHARPERATIO}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </center>
    </div>
  );
};

const MutualFundPage = () => {
  const [investorName, setInvestorName] = useState('');
  const [investmentAmount, setInvestmentAmount] = useState('');
  const [duration, setDuration] = useState('');
  const [riskTolerance, setRiskTolerance] = useState('');
  const [investmentGoal, setInvestmentGoal] = useState('');
  const [result, setResult] = useState(null);

  const calculateReturns = () => {
    const returns = investmentAmount * 0.05 * duration;
    setResult(returns);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateReturns();
  };

  return (
    <div className="background-container">
      <header>

        <h2>
          MUTUAL FUNDS
        </h2>
        <p>
          Mutual funds are a type of investment vehicle consisting of a
          portfolio of stocks, bonds, or other securities. They offer a way
          for investors to pool their money together, providing
          diversification and professional management. Use this calculator to
          estimate potential returns based on your investment details.
          Most mutual funds fall into one of four main categories – money market funds,
          bond funds, stock funds, and target date funds.
          Each type has different features, risks, and rewards.
          A mutual fund is an investment fund that pools money from many investors to purchase securities.
          The term is typically used in the United States, Canada, and India, while similar structures across the globe include the SICAV in Europe, and the open-ended investment company in the UK.
        </p>
      </header>
      {/* Image */}
      <div className="background-container" style={{ marginRight: '20px' }}>
        <img
          src="images/grap.png"
          alt="Graph"
          style={{ backgroundColor: '#87CEFA', width: '100', height: 'auto' }}
        />
      </div>
      <p>
        To understand how mutual funds work, let us first understand the concept of NAV (Net Asset Value).
        NAV per unit is the price at which investors can buy or redeem their mutual fund investments. Investors in mutual funds are allotted units proportional to their investments and this is calculated on the basis of the NAV. For example, if you invest Rs 500 in a mutual fund with an NAV of Rs 10, you will get (500/10), 50 units of the mutual fund.

        Now, the NAV of the mutual fund changes every day on the basis of the performance of the assets in the mutual fund is invested in.
        If a mutual fund invests in a particular stock whose price goes up tomorrow, the same will reflect in the NAV of the mutual fund and vice versa.
        So, in the above example, if the NAV of the mutual fund goes up to Rs 20, then your 50 units that amounted to Rs 500 earlier will now amount to Rs 1000 (500 units x Rs 20). Hence, the mutual fund’s performance is driven by its underlying assets, which generate its returns to investors.
      </p>
      <p>
        A mutual fund is a pool of money managed by a professional Fund Manager.
        It is a trust that collects money from a number of investors who share a common investment objective and invests the same in equities, bonds, money market instruments and/or other securities. And the income / gains generated from this collective investment is distributed proportionately amongst the investors after deducting applicable expenses and levies, by calculating a scheme’s “Net Asset Value” or NAV.
        Simply put, the money pooled in by a large number of investors is what makes up a Mutual Fund.
        Here’s a simple way to understand the concept of a Mutual Fund Unit.
        Let’s say that there is a box of 12 chocolates costing ₹40. Four friends decide to buy the same, but they have only ₹10 each and the shopkeeper only sells by the box. So the friends then decide to pool in ₹10 each and buy the box of 12 chocolates. Now based on their contribution, they each receive 3 chocolates or 3 units, if equated with Mutual Funds.
        And how do you calculate the cost of one unit? Simply divide the total amount with the total number of chocolates: 40/12 = 3.33.
        So if you were to multiply the number of units (3) with the cost per unit (3.33), you get the initial investment of ₹10.
        This results in each friend being a unit holder in the box of chocolates that is collectively owned by all of them, with each person being a part owner of the box.
        Next, let us understand what is “Net Asset Value” or NAV. Just like an equity share has a traded price, a mutual fund unit has Net Asset Value per Unit. The NAV is the combined market value of the shares, bonds and securities held by a fund on any particular day (as reduced by permitted expenses and charges). NAV per Unit represents the market value of all the Units in a mutual fund scheme on a given day, net of all expenses and liabilities plus income accrued, divided by the outstanding number of Units in the scheme.
        Mutual funds are ideal for investors who either lack large sums for investment, or for those who neither have the inclination nor the time to research the market, yet want to grow their wealth. The money collected in mutual funds is invested by professional fund managers in line with the scheme’s stated objective. In return, the fund house charges a small fee which is deducted from the investment. The fees charged by mutual funds are regulated and are subject to certain limits specified by the Securities and Exchange Board of India (SEBI).
      </p>
      <MutualFundPortfolio />
      <p align="left">
      <b>TYPE OF MUTUAL FUND SCHEMES</b></p>
      <p>
Mutual Fund schemes could be ‘open ended’ or close-ended’ and actively managed or passively managed.

OPEN-ENDED AND CLOSED-END FUNDS
An open-end fund is a mutual fund scheme that is available for subscription and redemption on every business throughout the year, (akin to a savings bank account, wherein one may deposit and withdraw money every day). An open ended scheme is perpetual and does not have any maturity date.

A closed-end fund is open for subscription only during the initial offer period and has a specified tenor and fixed maturity date (akin to a fixed term deposit). Units of Closed-end funds can be redeemed only on maturity (i.e., pre-mature redemption is not permitted). Hence, the Units of a closed-end fund are compulsorily listed on a stock exchange after the new fund offer, and are traded on the stock exchange just like other stocks, so that investors seeking to exit the scheme before maturity may sell their Units on the exchange.

ACTIVELY MANAGED AND PASSIVELY MANAGED FUNDS
An actively managed fund is a mutual fund scheme in which the fund manager “actively” manages the portfolio and continuously monitors the fund's portfolio , deciding on which stocks to buy/sell/hold and when, using his/her professional judgement, backed by analytical research. In an active fund, the fund manager’s aim is to generate maximum returns and out-perform the scheme’s bench mark.
      </p>
      <form className="background-container"
        onSubmit={handleSubmit}
        style={{ padding: '10px' }}
      >
        <h2>Fund calculator:</h2>
        <div>
          <label>
            <b> Investor Name:</b>
            <input
              type="text"
              value={investorName}
              onChange={(e) => setInvestorName(e.target.value)}
            />
          </label>
        </div>
        <div>
          <label>
            <b>Investment Amount ($):</b>
            <input
              type="number"
              value={investmentAmount}
              onChange={(e) => setInvestmentAmount(e.target.value)}
            />
          </label>
        </div>
        <div>
          <label>
            <b> Investment Duration (years):</b>
            <input
              type="number"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
            />
          </label>
        </div>
        <div>
          <label>
            <b> Risk Tolerance:</b>
            <select
              value={riskTolerance}
              onChange={(e) => setRiskTolerance(e.target.value)}
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </label>
        </div>
        <div>
          <label>
            <b>Investment Goal:</b>
            <textarea
              value={investmentGoal}
              onChange={(e) => setInvestmentGoal(e.target.value)}
            />
          </label>
        </div>
        <div>
          <button type="submit"> Calculate Returns </button>
        </div>
        {result !== null && (
          <div>
            <h2>Projected Returns:</h2>
            <p>${result}</p>
          </div>
        )}
      </form>
    </div>
  );
};

export default MutualFundPage;
