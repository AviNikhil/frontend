import React from "react";
import Header from "./Header";
import Footer from "./Footer";
function TranactionDetails(){
    return(
        <>
        <Header/>
      <div>
        Tranaction
      </div>
      <Footer/>
        </>
    )
}
export default TranactionDetails