import React from "react";
import Header from "./Header";
import Footer from "./Footer";
function DepositeWithdraw(){
    return(
        <>
     <Header/>
     <div>DepositeWithdraw</div>
     <Footer/>
        </>
    )
}
export default DepositeWithdraw