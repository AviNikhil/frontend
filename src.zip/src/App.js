import './App.css';
import { Route, Routes } from 'react-router-dom';
import Login from './Components/Login';
import Register from './Components/Register';
import Home from './Components/Home';
import Footer from './Components/Footer';
import Header from './Components/Header';
import About from './Components/About';
import Bills from './Components/Bills';
import TranactionDetails from './Components/TransactionDetails';
import DepositeWithdraw from './Components/DepositeWithdraw';
import AccountDetails from './Components/AccountDetails';
import Contact from './Components/Contact';
import StockPage from './Components/StockPage';
import MutualFundPage from './Components/MutualFundPage';

function App() {
  return (
   
    <div>
    <Routes>
        <Route path='/' element={<Login />} />
        <Route path='/register' element={<Register/>} />
        <Route path='/home' element={<Home/>} />
        <Route path='/about' element={<About/>} />
        <Route path='/mutual' element={<MutualFundPage/>} />
        <Route path='/bills' element={<Bills/>} />
        <Route path='/transactiondetails' element={<TranactionDetails/>} />
        <Route path='/deposite' element={<DepositeWithdraw/>} />
        <Route path='/accountdetails' element={<AccountDetails/>} />
        <Route path='/contact' element={<Contact/>} />
        <Route path='/stocks' element={<StockPage/>} />
    </Routes>
    </div>
  );
}

export default App;
